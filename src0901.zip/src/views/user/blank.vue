<template>
</template>
<script>

export default ({
  data() {
    this.$router.replace({
      path:'/user',
      name:'User'
    })
    return {
      
    }
  },
})
</script>
